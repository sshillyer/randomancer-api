// This file is private and ignored by git.

module.exports = {
	mongo: {
		development: {
			connectionString: 'mongodb://admin:hDrl6lksz@ds025603.mlab.com:25603/charmaker',
		},
		production: {
			connectionString: 'mongodb://admin:hDrl6lksz@ds025603.mlab.com:25603/charmaker',
		},
	},
};